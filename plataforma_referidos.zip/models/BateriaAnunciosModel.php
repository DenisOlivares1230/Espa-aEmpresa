<?php

class BateriaAnunciosModel extends Mysql{
			
		private $id;
	    private $nombre;
	    private $imagen;
	    private $expiracion;
	    private $puntos;
	    private $url;
	    private $numero;
	    private $adquirido;
	    private $user_id;
	    private $ciudad;

		function __construct(){
			
			parent::__construct();

	        $this->nombre = '';	
	        $this->imagen = '';
	        $this->expiracion = '';
	        $this->puntos = '';
	        $this->url = '';
	        $this->numero = '';
	        $this->adquirido = '';
	        $this->user_id = '';
	        $this->ciudad = '';


		}
		public function getAll(){
			session_start();
			$id = $_SESSION['user'];
			$query = "SELECT * FROM anuncios where user_id = '".$id."'";
			return $this->select_all($query);
			//return $_SESSION['user'];

		}
		public function get ($id){
			$query = 'SELECT * FROM anuncios WHERE id ="'.$id.'"';
			$item = $this->select($query);           	

            return $item;
		}
		public function updateProducto(){
			$query = "UPDATE anuncios SET 
			nombre=?,descripcion=?, 
			precio=?,inventario=?
			 WHERE id=?";
			
			$arrayDatos = array(
				$this->nombre,
				$this->descripcion,
				$this->precio,
				$this->inventario,
				$this->id);
			 $this->update($query, $arrayDatos);
			
			 return true;
		}
		function getId(){return $this->id;}
	
	    public function setAdquirido($adquirido){
	    	$this->adquirido = $adquirido;
	    }
	    public function setUser_id($user_id){
	    	$this->user_id = $user_id;
	    }
	    public function setCiudad($ciudad){
	    	$this->ciudad = $ciudad;
	    }
		



	}



?>