<?php

require_once("Models/UsuarioModel.php");

class RegistroModel extends Mysql{
		

	
	function __construct(){
		
	}
	function nuevoUsuario($usuario,$correo,$pass){

		$this->user = new UsuarioModel();

		$this->user->setUsuario($usuario);
		$this->user->setCorreo($correo);
		$this->user->setPassword($pass,tru);
		$this->user->setNivel('user');
		$this->user->setPhoto('default.png');
		$this->user->save();
	}
}
