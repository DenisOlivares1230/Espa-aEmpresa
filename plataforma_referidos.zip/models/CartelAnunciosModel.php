<?php

class CartelAnunciosModel extends Mysql{
			
		private $id;
	    private $nombre;
	   	private $expiracion;
	   
		function __construct(){
			
			parent::__construct();

			$this->id = '';
	        $this->nombre = '';	
	        $this->expiracion = '';
	        $this->adquirido = '';
	        


		}
		public function getAll(){
			$query = "SELECT * FROM anuncios where adquirido = '0'";
			return $this->select_all($query);
		}
		public function get ($id){
			$query = 'SELECT * FROM anuncios WHERE id ="'.$id.'"';
			$item = $this->select($query);           	

            return $item;
		}
		public function updateExpiracion(){
			$query = "UPDATE anuncios SET 
			expiracion=? WHERE id=?";
			
			$arrayDatos = array(
				$this->expiracion,
				$this->id);
			 
			$this->update($query, $arrayDatos);
			
			 return true;

		}
		public function borrar($id){
			$query = "DELETE FROM anuncios WHERE id =".$id;
			$this->delete($query);
			return true;
		}
		
		function getId(){return $this->id;}
	
	    public function setId($id){$this->id = $id;}
	    public function setNombre($nombre){$this->nombre = $nombre;
	    }  
	    public function setExpiracion($agno,$mes,$dia,$hora,$min){
	    	$expira = $agno ."-". $mes ."-". $dia ." ". $hora .":". $min .":". 00;
	    	$this->expiracion = $expira;
	    }
		



	}


?>