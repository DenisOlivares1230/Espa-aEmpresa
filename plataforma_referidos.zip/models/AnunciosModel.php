<?php

class AnunciosModel extends Mysql{
			
		private $id;
	    private $nombre;
	    private $imagen;
	    private $expiracion;
	    private $puntos;
	    private $url;
	    private $numero;
	    private $adquirido;
	    private $user_id;
	    private $ciudad;

		function __construct(){
			
			parent::__construct();

	        $this->nombre = '';	
	        $this->imagen = '';
	        $this->expiracion = '';
	        $this->puntos = '';
	        $this->url = '';
	        $this->numero = '';
	        $this->adquirido = '';
	        $this->user_id = '';
	        $this->ciudad = '';


		}
		public function save (){
			$query = "INSERT INTO anuncios 
			(nombre,imagen,expiracion,puntos,
			url,numero,adquirido,user_id,ciudad) 
			values (?,?,?,?,?,?,?,?,?)";

			$arrayDatos = array(
				$this->nombre,
				$this->imagen,
				$this->expiracion,
				$this->puntos,
				$this->url,
				$this->numero,
				'0',
				0,
				'sin adquirir');
			 $this->insert($query, $arrayDatos);
			 return true;
		}
		public function getAll(){
			$query = "SELECT * FROM anuncios";
			return $this->select_all($query);
		}
		public function get ($id){
			$query = 'SELECT * FROM anuncios WHERE id ="'.$id.'"';
			$item = $this->select($query);           	

            return $item;
		}
		public function borrar($id){
			$query = "DELETE FROM anuncios WHERE id =".$id;
			$this->delete($query);
			return true;
		}
		public function updateProducto(){
			$query = "UPDATE anuncios SET 
			nombre=?,descripcion=?, 
			precio=?,inventario=?
			 WHERE id=?";
			
			$arrayDatos = array(
				$this->nombre,
				$this->descripcion,
				$this->precio,
				$this->inventario,
				$this->id);
			 $this->update($query, $arrayDatos);
			
			 return true;
		}
		function getId(){return $this->id;}
	
	    public function setId($id){$this->id = $id;}
	    public function setNombre($nombre){$this->nombre = $nombre;
	    }  
	    public function setImagen($imagen){

	    	$tmp = $imagen['tmp_name'];
	    	$nombre_imagen = bin2hex(random_bytes(2)).time();
	    	$carpeta = "Assets/images/Uploads/anuncios/";
		    move_uploaded_file($imagen['tmp_name'],$carpeta.$nombre_imagen.$imagen['name']); 
	    	$this->imagen = $nombre_imagen.$imagen['name'];
	    }
	    public function setExpiracion($agno,$mes,$dia,$hora,$min){
	    	$expira = $agno ."-". $mes ."-". $dia ." ". $hora .":". $min .":". 00;
	    	$this->expiracion = $expira;
	    }
	    public function setPuntos($puntos){
	    		$this->puntos = $puntos;
	   	}
	    public function setUrl($url){	
	    		$this->url = $url;
	    }
	    public function setNumero($numero){
	    	$this->numero = $numero;
	    }
	    public function setAdquirido($adquirido){
	    	$this->adquirido = $adquirido;
	    }
	    public function setUser_id($user_id){
	    	$this->user_id = $user_id;
	    }
	    public function setCiudad($ciudad){
	    	$this->ciudad = $ciudad;
	    }
		



	}



?>