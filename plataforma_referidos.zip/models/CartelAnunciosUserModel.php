<?php

require_once('Models/UsuarioModel.php');

class CartelAnunciosUserModel extends Mysql{
			
		private $id;
	    private $nombre;
	    private $userId; 
	    private $adquirido;

	    private $user;
	   
		function __construct(){
			
			parent::__construct();

			$this->id = '';
	        $this->nombre = '';	
	        $this->userId = '';
	        $this->adquirido = '';
		}
		public function getAll(){
			$query = "SELECT * FROM anuncios where adquirido = '0'";
			return $this->select_all($query);
		}
		public function get ($id){
			$query = 'SELECT * FROM anuncios WHERE id ="'.$id.'"';
			$item = $this->select($query);           	

            return $item;
		}
		public function updateAd(){

			$this->user = new UsuarioModel();
			
			$query = "UPDATE anuncios SET 
			user_id=?,adquirido=? 
			WHERE id=?";
			
			$arrayDatos = array(
				$_SESSION['user'],
				'1',
				$this->id);
			 $this->update($query, $arrayDatos);
			
			 return true;

		}
		function getId(){return $this->id;}
	
		public function setId($id){
	     	$this->id = $id;
	     }
	    public function setUserId($userId){
	     	$this->userId = $userId;
	     }
	    public function setAdquirido($adquirido){
	     	$this->adquirido = $adquirido;

	     }
	    
		



	}


?>