<?php

	class UsuarioModel extends Mysql{
			
		private $id;
	    private $usuario;
	    private $correo;
	    private $password;
	    private $nivel;
	    private $photo;
	    
	    private $name;

		function __construct(){
			parent::__construct();

	        $this->username = '';
	        $this->password = '';
	        $this->nivel = '';
	        $this->photo = '';	

		}
		public function save (){
			$query = "INSERT INTO usuarios 
			(usuario,correo,password,nivel,photo) 
			values (?,?,?,?,?)";

			$arrayDatos = array(
				$this->usuario,
				$this->correo,
				$this->password,
				$this->nivel,
				$this->photo);
			 $this->insert($query, $arrayDatos);

			 return true;
		}
		public function getAll(){
			$query = "SELECT * FROM usuarios";
			return $this->select_all($query);
		}
		public function get ($id){
			$query = 'SELECT * FROM usuarios WHERE id ='.$id;
			$item = $this->select($query);           	

            $this->id = $item['id'];
            $this->usuario = $item['usuario'];
            $this->correo = $item['correo'];
            $this->password = $item['password'];
            $this->nivel = $item['nivel'];
            $this->photo = $item['photo'];

            return $item;
		}
		public function getUser ($id){
			$query = 'SELECT * FROM usuarios WHERE id ='.$id;
			$item = $this->select($query);           	
            return $item;
		}
		public function borrar($id){
			$query = "DELETE FROM usuarios WHERE id =".$id;
			$this->delete($query);
			return true;
		}
		public function updateUser(){
			$query = "UPDATE usuarios SET usuario=?,correo=?,nivel=?,password=? WHERE id=?";

			$arrayDatos = array(
				$this->usuario,
				$this->correo,
				$this->nivel,
				$this->password,
				$this->id);
			 $this->update($query, $arrayDatos);

			 return true;
		}
		public function searchUser($usuario){
			$query = "SELECT * FROM usuarios where correo like '%".$usuario."%'";
			return $this->select_all($query);
		}
		function from($array){
			$this->id = $array['id'];
	        $this->usuario = $array['usuario'];
	        $this->correo = $array['correo'];
	        $this->password = $array['password'];
	        $this->nivel = $array['nivel'];
	        $this->photo = $array['photo'];	
		}
		private function getHashedPassword($password){
	        return password_hash($password, PASSWORD_DEFAULT, ['cost' => 10]);
	    }
		function getId(){return $this->id;}
		function getName(){return $this->name;}
		function getPhoto(){return $this->photo;}
		function getPassword(){return $this->password;}
		function getnivel(){return $this->nivel;}	

		public function setUsuario($usuario){ $this->usuario = $usuario;
		}
	    public function setCorreo ($correo){
	    	$this->correo = $correo;	
	    }
	    public function setPassword2 ($password){
	    	$this->password = $password;	
	    }
		public function setPassword($password, $hash = true){
	        if($hash){
	            $this->password = $this->getHashedPassword($password);
	        }else{
	            $this->password = $password;
	        } }
	    public function setId($id){             $this->id = $id;}
	    public function setNivel($nivel){$this->nivel = $nivel; }
	    public function setPhoto($photo){$this->photo = $photo; }
	}


