<?php

	require_once("Models/UsuarioModel.php");

	class LoginModel extends Mysql{
		
		function __construct(){
			
			parent::__construct();	

		}
		function selectUser(string $correo, $password){
			
			$query = 
			"SELECT * from usuarios 
			where correo = '".$correo."'";

			$items = $this->select($query);


			$user = new UsuarioModel();
			$user->from($items);
			
			if(password_verify($password,$user->getPassword())){

				return $user;

			}else{

				return NULL;

			}

		}

	}
