<?php

	const BASE_URL = "http://localhost/Plataforma_referidos";

	const ASSETS = BASE_URL."/Assets";

	date_default_timezone_set('America/Caracas');


	const DB_HOST = "localhost";
	const DB_NAME = "plataforma_afiliados";
	const DB_USER = "root";
	const DB_PASSWORD = "";
	const DB_CHARSET = "charset =utf8";


	const SPD = ".";
	const SPM = ",";

	const SMONEY = "$";