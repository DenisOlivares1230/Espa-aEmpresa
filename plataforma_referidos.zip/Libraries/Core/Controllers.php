<?php


class Controllers{
	
	public function __construct(){
		
		$this->views = new Views();
		$this->loadModel();


	}
	public function loadModel (){
		$model = get_class($this)."Model";
		$routClass = "Models/".$model.".php";
		if (file_exists($routClass)) {
			require_once ($routClass);
			$this->model = new $model();

		}

	}
	function existPOST($params){
        foreach ($params as $param) {
            if(!isset($_POST[$param])){
                return false;
            }
        }
        
        return true;
    }
    function existGET($params){
        foreach ($params as $param) {
            if(!isset($_GET[$param])){
                return false;
            }
        }
        return true;
    }
    function getGet($name){
        return $_GET[$name];
    }
    function getPost($name){
        return $_POST[$name];
    }

}

