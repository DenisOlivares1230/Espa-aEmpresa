<?php


require_once('Models/UsuarioModel.php');

class SessionController extends Controllers{

	private $userSession;
    private $username;
    private $userid;

    private $session;
    private $sites;

    private $user;


	function __construct(){
		
		parent::__construct();
		
		$this->init();

	}
	private function init(){
		//Crear session
		$this->session = new Session();

		$json = $this->getJSONFileConfig();

		$this->sites = $json['sites'];
		
		$this->defaultSites = $json['default-sites'];

		$this->validateSession();
	}
	private function getJSONFileConfig(){
		$string = file_get_contents('Config/access.json');
		$json = json_decode($string, True);
		return $json;
	}
	function validateSession (){

		//dep($this->defaultSites['admin']);
		

		if ($this->existSession()) {
			$role = $this->getUserSessionData()->getNivel();
				
			if ($this->isPublic()){
				$this->redirectDefaultSiteByRole($role);	
			}else{
				//Tengo que hacer pruebas a partir de acá
				if ($this->isAuthorized($role)) {
					//Lo deja pasar
				}else{
					$this->redirectDefaultSiteByRole($role);
				}
			}
		}else{
			if ($this->isPublic()) {
				//La página es publica
				
			}else{
				header("location: ".base_url());
			}
		}
	}
	function isPublic(){

		$currentURL = $this->getCurrentPage();
		$currentURL = preg_replace("/\?.*/","",$currentURL);
		//echo "<script>alert()</script>";
		//dep($this->sites[1]['site']);
		//echo $currentURL;
		for($i = 0; $i < count($this->sites); $i++){
				
			if ($currentURL === $this->sites[$i]['site'] 
				&& $this->sites[$i]['access'] === 'public') {

				 return true;
			}
		}
				
		return false;
		echo $currentURL;
	}
	function existSession (){
			
		if (!$this->session->exist()) return false;
		if($this->session->getCurrentUser() == NULL) return false;

		$userId = $this->session->getCurrentUser();
		if ($userId) return true;
		return false;
	}
	function getUserSessionData(){
		//echo "<script>alert('".$id."');</script>";
		$id = $this->session->getCurrentUser();
		$this->user = new UsuarioModel();
		$this->user->get($id);
		return $this->user;	
	}
	function redirectDefaultSiteByRole($role){
		$url = '';

		for ($i=0; $i < count($this->sites); $i++) { 
			
			if ($this->sites[$i]['role'] == $role) {
				$url = $this->sites[$i]['site'];
	            break;

			}
		}
		echo "<script>alert('".$role."');</script>";
		header("location: ".base_url()."/".$url);

	}
	public function initialize($user){
		$this->session->setCurrentUser($user->getId());
        $this->authorizeAccess($user->getNivel());

	}
	function getCurrentPage(){
		$actual_link = trim("$_SERVER[REQUEST_URI]");
		$url = explode('/', $actual_link);
		return $url[2];
	}
	function isAuthorized($role){
		$currentURL = $this->getCurrentPage();
        $currentURL = preg_replace( "/\?.*/", "", $currentURL); //omitir get info
        
        for($i = 0; $i < count($this->sites); $i++){
            if($currentURL === $this->sites[$i]['site'] 
            	&& $this->sites[$i]['role'] === $role){
                return true;
            }
        }
        return false;
	}
	function authorizeAccess ($role){

		switch ($role) {
			case 'user':
				header("Location: ".base_url()."/".$this->defaultSites['user']);
				break;
			case 'admin':
				header("Location: ".base_url()."/".$this->defaultSites['admin']);
				break;
		}

	}
	function logout(){
        $this->session->closeSession();
        header("Location: ".base_url());
        
    }

}