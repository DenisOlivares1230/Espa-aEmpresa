CREATE DATABASE plataforma_afiliados;

use platafor_afiliados

CREATE TABLE usuarios (
	id int(11) NOT NULL auto_increment,
	usuario varchar(50) NOT NULL,
	correo varchar(50) NOT NULL,
	password varchar(300) NOT NULL,
	nivel enum('user','admin') NOT NULL,
	photo varchar(300) NOT NULL,
	PRIMARY KEY(id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE anuncios (
	id int(11) NOT NULL auto_increment,
	nombre varchar(30) NOT NULL,
	imagen varchar(50) not null,
	expiracion datetime not null,
	puntos int(11) not null,
	url text not null,
	numero varchar (50) not null,
	adquirido enum('0','1') not null,
	user_id int(11) not null,
	ciudad varchar(200) not null,
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

