<?= headerDashboard($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">
            <?= $data['tag_name'] ?>
            </a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Historial</h3>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Usuario</th>
                  <th>Actividad</th>
                  <th></th>
                </tr>
              </thead>
              <tbody id="mostrar_solicitudes">
                <tr class='solicitud'>
                  <th class="id">1</th>
                  <th>Carlos@gmail.com</th>
                  
                  <th>Envio un mail</th>
                  <th>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#leerMail">
                      Ver actividad
                    </button>
                  </th>  
                </tr>
                
                
                

              </tbody>
            </table>
          </div>
        </div>
        
      </div>
      
    </main>

<?php footerDashboard($data) ?>