<?= headerAdmin($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">
            <?= $data['tag_name'] ?>
            </a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12 mb-1">
          <div class="tile row">
            <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#nuevoUsuario">
              Nuevo usuario
            </button> -->
            <div>
              <form id="buscar_usuario" class="form-inline"> 
                 <div class="form-group mx-sm-3 mb-2">
                  <label for="inputPassword2" class="sr-only">
                    Buscar usuario
                  </label>
                  <input type="text" class="form-control" placeholder="usuarios@gmail.com" name="usuario">
                </div>
                <button type="submit" class="btn btn-primary mb-2">
                  Buscar usuario
                </button>
              </form>
            </div>
          </div>
          
        </div> 
      
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Listado de usuarios</h3>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Photo</th>
                  <th>Nombre</th>
                  <th>Nivel</th>
                  <th>Correo</th>
                  <th></th>
              
                </tr>
              </thead>
              <tbody id="mostrar_usuarios">
                
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
    </main>

<!-- Modal agregar usuario -->
<div class="modal fade" id="nuevoUsuario" tabindex="-1" role="dialog" aria-labelledby="nuevoUsuarioLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="nuevoUsuarioLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">
          Nuevo usuario
        </button>
      </div>
    </div>
  </div>
</div>
<!-- Modal actividad-->
<div class="modal fade" id="actividad" tabindex="-1" role="dialog" aria-labelledby="actividadLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="actividadLabel">
          Actividad de usuario  
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Actividad</th>
                  <th>Fecha/hora</th>
            
                </tr>
              </thead>
              <tbody id="mostrar_actividad">
                <tr class='usuario'>
                  <th class="id">1</th>
                  <th>
                    Adquirió el anuncio: "Nombre anuncio"
                  </th>
                  <th>25/02/2023 a las 9:54</th>
                </tr>
                <tr class='usuario'>
                  <th class="id">1</th>
                  <th>
                    Adquirió el anuncio: "Nombre anuncio"
                  </th>
                  <th>25/02/2023 a las 9:54</th>
                </tr>
                <tr class='usuario'>
                  <th class="id">1</th>
                  <th>
                    Solicitud de pago "Paypal"
                  </th>
                  <th>25/02/2023 a las 9:54</th>
                </tr>
                
              </tbody>
            </table>
      </div>

    </div>
  </div>
</div>

<!-- Modal editar usuario -->
<div class="modal fade" id="Editar" tabindex="-1" role="dialog" aria-labelledby="EditarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EditarLabel">
          Editar usuario
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form_edit">
        <input type="hidden" name="id">
        <div class="modal-body">
          <div class="form-group">
            <label>
              Nombre
            </label>
            <input class="form-control inputs" placeholder="Nombre" name="nombre">
          </div>

          <div class="form-group">
            <label>
              Correo electrónico
            </label>
            <input class="form-control inputs" placeholder="Correo electrónico" name="correo">
          </div>

          <div class="form-group">
            <label>
              Nivel
            </label>
            <select class="form-control" name="select_edit">
              <option value="user">user</option>
              <option value="admin">admin</option>
            </select>
          </div>

          <div class="form-group">
            <label>
              Password
            </label>
            <input class="form-control" placeholder="password" name="password">
          </div>
          
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">
            Editar datos
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Eliminar usuario -->
<div class="modal fade" id="Eliminar" tabindex="-1" role="dialog" aria-labelledby="EliminarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EliminarLabel">
          ¡Eliminar usuario!
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form_delete">
        <div class="modal-body">
          <input type="hidden" name="id">
          ¿Estás seguro que quieres eliminar este usuario?
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">
            ¡Eliminar!
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php footerAdmin($data) ?>