
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user">
        <img class="app-sidebar__user-avatar" 
        src="<?= media() ?>/images/default.png" alt="User Image" style="width: 40px; height: 40px">
        <div>
          <p class="app-sidebar__user-name">
            Marcos Vargas
          </p>
          <p class="app-sidebar__user-designation">
            Usuario
          </p>
        </div>
      </div>
     
      <!-- MENU -->
      <ul class="app-menu">
        <li><a class="app-menu__item <?php if($data['tag_name'] == 'Dashboard'){echo 'active';} ?>" 
            href="<?= base_url()?>/Dashboard">
              <i class="app-menu__icon fa fa-dashboard"></i>
              <span class="app-menu__label">
                Administrador
              </span>
            </a>
        </li>
        <li><a class="app-menu__item <?php if($data['tag_name'] == 'Cartel anuncios'){echo 'active';} ?>"  
            href="<?= base_url()?>/CartelAnunciosUser">
            <i class="app-menu__icon fa fa-clipboard"></i>
            <span class="app-menu__label">Cartel de Anuncios</span>
          </a>
        </li>
        <li><a class="app-menu__item <?php if($data['tag_name'] == 'Bateria de anuncios'){echo 'active';} ?>" 
            href="<?= base_url()?>/BateriaAnuncios">
            <i class="app-menu__icon fa fa-battery-three-quarters "></i>
            <span class="app-menu__label">Bateria de Anuncios</span>
          </a>
        </li>

        <li><a class="app-menu__item <?php if($data['tag_name'] == 'Solicitudes'){echo 'active';} ?>" 
            href="<?= base_url()?>/SolicitudesUser">
            <i class="app-menu__icon fa fa-bell"></i>
            <span class="app-menu__label">Solicitudes</span>
          </a>
        </li>

        <li><a class="app-menu__item <?php if($data['tag_name'] == 'Mails'){echo 'active';} ?>" 
            href="<?= base_url()?>/MailsUser">
            <i class="app-menu__icon fa fa-envelope-o"></i>
            <span class="app-menu__label">Mails</span>
          </a>
        </li>

        <li><a class="app-menu__item <?php if($data['tag_name'] == 'HistorialUser'){echo 'active';} ?>" 
            href="<?= base_url()?>/HistorialUser">
            <i class="app-menu__icon fa fa-history"></i>
            <span class="app-menu__label">Historial</span>
          </a>
        </li>
        
      </ul>
    </aside>