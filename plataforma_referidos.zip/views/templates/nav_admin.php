
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user">
        <img class="app-sidebar__user-avatar" 
        src="<?= media() ?>/images/default.png" alt="User Image" style="width: 60px; height: 60px">
        <div>
          <p class="app-sidebar__user-name">
            Marcos Vargas
          </p>
          <p class="app-sidebar__user-designation">
            Administrador
          </p>
        </div>
      </div>
     
      <!-- MENU -->
      <ul class="app-menu">
        <li><a class="app-menu__item 
          <?php if($data['tag_name']== 'Administrador'){ echo 'active';}?>" href="<?= base_url() ?>/Admin">
              <i class="app-menu__icon fa fa-dashboard"></i>
              <span class="app-menu__label">
                Administrador
              </span>
            </a>
        </li>
        <li><a class="app-menu__item <?php if($data['tag_name']== 'Cartel anuncios'){ echo 'active';}?>" 
            href="<?= base_url()?>/CartelAnuncios">
            <i class="app-menu__icon fa fa-clipboard"></i>
            <span class="app-menu__label">Cartel de Anuncios</span>
          </a>
        </li>

        <li><a class="app-menu__item <?php if($data['tag_name']== 'Anuncios'){ echo 'active';}?>" href="<?= base_url()?>/Anuncios">
            <i class="app-menu__icon fa fa-address-card-o"></i>
            <span class="app-menu__label">Anuncios</span>
          </a>
        </li>
        
        <li><a class="app-menu__item <?php if($data['tag_name']== 'Usuarios'){ echo 'active';}?>" href="<?= base_url()?>/Usuarios">
            <i class="app-menu__icon fa fa-users"></i>
  
            <span class="app-menu__label">Usuarios</span>
          </a>
        </li>
        <li><a class="app-menu__item <?php if($data['tag_name']== 'Solicitudes'){ echo 'active';}?>" href="<?= base_url()?>/Solicitudes">
            <i class="app-menu__icon fa fa-bell-o fa-lg"></i>
  
            <span class="app-menu__label">Solicitudes</span>
          </a>
        </li>
        <li><a class="app-menu__item <?php if($data['tag_name']== 
        'Historial'){ echo 'active';}?>" href="<?= base_url()?>/Historial">
            <i class="app-menu__icon fa fa-history"></i>
  
            <span class="app-menu__label">Historial</span>
          </a>
        </li>
        <li>
          <a class="app-menu__item <?php if($data['tag_name']== 'Mails'){ echo 'active';}?>" href="<?= base_url()?>/Mails">
            <i class="app-menu__icon fa fa-envelope-o" aria-hidden="true"></i>
  
            <span class="app-menu__label"> Mails</span>
          </a>
        </li>
        
        
      </ul>
    </aside>