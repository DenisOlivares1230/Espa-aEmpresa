<?= headerAdmin($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">
            <?= $data['tag_name'] ?>
            </a></li>
        </ul>
      </div>
      <style type="text/css">
       
        
        .anuncio img{
          height: 200px;
        }

      </style>
      <div class="row" id="mostrar_cartel_anuncios">

        
      </div>
      
    </main>

<!-- Button trigger modal -->


<!-- Configuración de anuncio -->
<div class="modal fade" id="configuracion" tabindex="-1" role="dialog" aria-labelledby="configuracionLabel" aria-hidden="true">

  <div class="modal-dialog" role="docume
  nt">
    <div class="modal-content">
      <div class="modal-header">
        
        <h6 class="modal-title" id="configuracionLabel">
          Renovar anuncio
        </h6>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form_renovar">
        <input type="hidden" name="id">
        <div class="modal-body">

            <div class="row">
              <div class="col-12">
                <label>
                  <h2>Renovar anuncio</h2>
                </label>
              </div>
              <br>
              <div class="col-12 row">
                <!-- FECHA -->
                <div class="form-group col-4">
                  <label for="agno">
                    Año
                  </label>
                  <select class="form-control" id="agno" name="agno">
                    <option>2023</option>
                    <option>2024</option>
                    <option>2025</option>
                  </select>
                </div>
                <div class="form-group col-4">
                  <label for="mes">
                    Mes
                  </label>
                  <select class="form-control" id="mes" name="mes">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                  </select>
                </div>
                <div class="form-group col-4">
                  <label for="dia">
                    Día
                  </label>
                  <select class="form-control" id="dia" name="dia">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
                    <option>24</option>
                    <option>25</option>
                    <option>26</option>
                    <option>27</option>
                    <option>28</option>
                    <option>29</option>
                    <option>30</option>
                    <option>31</option>
                  </select>
                </div>
                <!--Horas/minutos  -->
                <div class="form-group col-4">
                  <label for="hora">
                    Horas
                  </label>
                  <select class="form-control" id="hora" name="hora">
                    <option>0</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    <option>11</option>
                    <option>12</option>
                    <option>13</option>
                    <option>14</option>
                    <option>15</option>
                    <option>16</option>
                    <option>17</option>
                    <option>18</option>
                    <option>19</option>
                    <option>20</option>
                    <option>21</option>
                    <option>22</option>
                    <option>23</option>
                  </select>
                </div>
                <div class="form-group col-4">
                  <label for="minuto">
                    Minutos
                  </label>
                  <select class="form-control" id="minuto" name="minutos">
                    <option>00</option>
                    <option>15</option>
                    <option>30</option>
                    <option>45</option>
                  </select>
                </div>
              </div>
            </div>

        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary">
              Renovar
            </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- Eliminar anuncio  -->
<div class="modal fade" id="Eliminar" tabindex="-1" role="dialog" aria-labelledby="EliminarLabel" aria-hidden="true">

  <div class="modal-dialog" role="docume
  nt">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EliminarLabel">
          Eliminar anuncio
        </h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form_delete">
        <div class="modal-body">
          ¿Estas seguro que quieres eliminar el anuncio?
          <input type="hidden" value="" name="id">
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">
            Eliminar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php footerAdmin($data) ?>
