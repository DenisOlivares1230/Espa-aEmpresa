<?= headerDashboard($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">
            <?= $data['tag_name'] ?>
            </a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-12 mt-2">
              <div class="tile">
                <h3 class="tile-title">
                  Listado de anuncios
                </h3>
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>#</th>
                    <th></th>
                    <th>Nombre</th>
                    <th>Puntos</th>
                    
                    <th></th>

                  </tr>
                </thead>
                <tbody id="mostrar_anuncios">
                  
                  
                  
                </tbody>
              </table>
            </div>
          </div>

        
      </div>
    </main>


<!-- Detalles de anuncio -->
<div class="modal fade bd-example-modal-lg" id="detalleAnuncio" tabindex="-1" role="dialog" aria-labelledby="detalleAnuncioLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="detalleAnuncioLabel">
          Detalles del anuncio
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <div class="modal-body">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Puntos</th>
                <th>URL</th>
                <th>Número</th>
                <th>Ciudad</th>
              </tr>
            </thead>
            <tbody id="mostrar_detalles_anuncios">
              
            </tbody>
          </table>

          <hr>
          <form id="id_mandar">
            <input type="hidden" name="id">
          </form>
          <form id="form_city">
            
          </form>
        </div>
        <div class="modal-footer">
         

        </div>
    </div>
  </div>
</div>

<?php footerDashboard($data) ?>