<?= headerAdmin($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">
            <?= $data['tag_name'] ?>
            </a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Solicitudes</h3>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Usuario</th>
                  <th>Puntos</th>
                  <th>Dólares</th>
                  <th></th>
                </tr>
              </thead>
              <tbody id="mostrar_solicitudes">
                <tr class='solicitud'>
                  <th class="id">1</th>
                  <th>Carlos@gmail.com</th>
                  
                  <th>10 Pts</th>
                  <th>20 $</th>  
                </tr>
                <tr class='solicitud'>
                  <th class="id">2</th>
                  <th>Carlos@gmail.com</th>
                  
                  <th>10 Pts</th>
                  <th>20 $</th>  
                </tr>
                <tr class='solicitud'>
                  <th class="id">3</th>
                  <th>Carlos@gmail.com</th>
                  
                  <th>10 Pts</th>
                  <th>20 $</th>  
                </tr>
                
                

              </tbody>
            </table>
          </div>
        </div>
        
      </div>
      
    </main>

<?php footerAdmin($data) ?>