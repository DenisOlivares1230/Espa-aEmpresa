<?= headerDashboard($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">
            <?= $data['tag_name'] ?>
            </a></li>
        </ul>
      </div>

      <div class="row">
          <div class="col-12">
            <div class="tile">
              <!-- Botod de solicitud -->
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#hacerSolicitud">
                Hacer solicitud
              </button>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Solicitudes</h3>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Usuario</th>
                  <th>Puntos</th>
                  <th>Dólares</th>
                  <th></th>
                </tr>
              </thead>
              <tbody id="mostrar_solicitudes">
                <tr class='solicitud'>
                  <th class="id">1</th>
                  <th>Carlos@gmail.com</th>
                  
                  <th>10 Pts</th>
                  <th>20 $</th>  
                </tr>
                <tr class='solicitud'>
                  <th class="id">2</th>
                  <th>Carlos@gmail.com</th>
                  
                  <th>10 Pts</th>
                  <th>20 $</th>  
                </tr>
                <tr class='solicitud'>
                  <th class="id">3</th>
                  <th>Carlos@gmail.com</th>
                  
                  <th>10 Pts</th>
                  <th>20 $</th>  
                </tr>
                
                

              </tbody>
            </table>
          </div>
        </div>
        
      </div>
    </main>

<!-- Modal de petición de solicitud -->
<div class="modal fade" id="hacerSolicitud" tabindex="-1" role="dialog" aria-labelledby="hacerSolicitudLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="hacerSolicitudLabel">
          Hacer solicitud
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
<?php footerDashboard($data) ?>