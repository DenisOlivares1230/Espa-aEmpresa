<?= headerDashboard($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">
            <?= $data['tag_name'] ?>
            </a></li>
        </ul>
      </div>
      <div class="row" id="mostrar_anuncios">
      
      </div>
      
    </main>


<!-- Adquirir usuario -->
<div class="modal fade" id="Adquirir" tabindex="-1" role="dialog" aria-labelledby="AdquirirLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="AdquirirLabel">
          ¡Adquirir anuncio!
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form_adquirir">
        <div class="modal-body">
          <input type="hidden" name="id">
          ¿Quieres adquirir este anuncio?
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">
            ¡Adquirir!
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php footerDashboard($data) ?>