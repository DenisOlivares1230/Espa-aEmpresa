<?php headerAdmin($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">
            <?= $data['tag_name'] ?>
            </a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-12 mb-3">
          <h2>Resumen de módulos</h2>
        </div>
        <div class="col-md-6 col-lg-6">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-users fa-3x"></i>
            <div class="info">
              <h4>Users</h4>
              <p><b>5</b></p>
            </div>
          </div>
        </div>
        
        <div class="col-md-6 col-lg-6">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-files-o fa-3x"></i>
            <div class="info">
              <h4>Anuncios en el cartel</h4>
              <p><b>10</b></p>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-6">
          <div class="widget-small danger coloured-icon"><i class="icon fa fa-bell-o fa-lg"></i>
            <div class="info">
              <h4>Solicitudes</h4>
              <p><b>10</b></p>
            </div>
          </div>
        </div>
        
        <div class="col-md-6 col-lg-6">
          <div class="widget-small info coloured-icon">
            <i class="icon fa fa fa-envelope-o"></i>
            <div class="info">
              <h4>Mails</h4>
              <p><b>25</b></p>
            </div>
          </div>
        </div>
      
      </div>
      <div class="row">
       
      </div>
    </main>

<?php footerAdmin($data) ?>