<?= headerAdmin($data) ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>
             <?= $data['tag_name'] ?>
          </h1>
          <p>
          </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">
            <a href="#"><?= $data['tag_name'] ?></a>
          </li>
        </ul>
       
      </div>
      
      
        <div class="row">
          <div class="col-12">
            <div class="tile">
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#nuevoAnuncio">
                Nuevo anuncio
              </button>

              <button type="button" class="btn btn-primary">
                Mostrar anuncios adquiridos
              </button>

              <button type="button" class="btn btn-primary">
                Mostrar anuncios sin adquirir
              </button>
            </div>
          </div>

          <div class="col-12 mt-2">
              <div class="tile">
                <h3 class="tile-title">
                  Listado de anuncios
                </h3>
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>#</th>
                    <th></th>
                    <th>Nombre</th>
                    <th>Fecha de expiración</th>
                    <th>Puntos</th>
                    <th>Estado</th>
                    <th></th>

                  </tr>
                </thead>
                <tbody id="mostrar_anuncios">
                  
                  
                </tbody>
              </table>
            </div>
          </div>
        </div> 
              
          

        
      
      
    </main>
<!-- Nuevo anuncio -->
<div class="modal fade" id="nuevoAnuncio" tabindex="-1" role="dialog" aria-labelledby="nuevoAnuncioLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="nuevoAnuncioLabel">
          Añadir anuncio
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form_add_anuncio">
        <div class="modal-body">

          <div class="form-group">
            <label>
              Nombre
            </label>
            <input class="form-control inputs" placeholder="Anuncio" name="nombre">
          </div>

          <div class="form-group">
            <label>
              Número
            </label>
            <input class="form-control inputs" placeholder="+44 6138 973367" name="numeros">
          </div>

          <div class="form-group">
            <label>
              Puntos
            </label>
            <input class="form-control inputs" placeholder="4" name="puntos">
          </div>

          <div class="form-group">
            <label>
              URL
            </label>
            <input class="form-control inputs" placeholder="https://www.google.com" name="url">
          </div>


          <div class="form-group">
            <label for="imagen">
              Imagen de anuncio
            </label>
            <input type="file" class="form-control-file" 
            id="imagen" name="imagen">
          </div>

          <hr>
          <div class="row">
            <div class="col-12">
              <label>
                Fecha expiración <br>
              </label>
            </div>
            <div class="col-12 row">
              <!-- FECHA -->
              <div class="form-group col-4">
                <label for="agno">
                  Año
                </label>
                <select class="form-control" id="agno" name="agno">
                  <option>2023</option>
                  <option>2024</option>
                  <option>2025</option>
                </select>
              </div>
              <div class="form-group col-4">
                <label for="mes">
                  Mes
                </label>
                <select class="form-control" id="mes" name="mes">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                  <option>7</option>
                  <option>8</option>
                  <option>9</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                </select>
              </div>
              <div class="form-group col-4">
                <label for="dia">
                  Día
                </label>
                <select class="form-control" id="dia" name="dia">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                  <option>7</option>
                  <option>8</option>
                  <option>9</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                  <option>13</option>
                  <option>14</option>
                  <option>15</option>
                  <option>16</option>
                  <option>17</option>
                  <option>18</option>
                  <option>19</option>
                  <option>20</option>
                  <option>21</option>
                  <option>22</option>
                  <option>23</option>
                  <option>24</option>
                  <option>25</option>
                  <option>26</option>
                  <option>27</option>
                  <option>28</option>
                  <option>29</option>
                  <option>30</option>
                  <option>31</option>
                </select>
              </div>
              <!--Horas/minutos  -->
              <div class="form-group col-4">
                <label for="hora">
                  Horas
                </label>
                <select class="form-control" id="hora" name="hora">
                  <option>0</option>
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                  <option>7</option>
                  <option>8</option>
                  <option>9</option>
                  <option>10</option>
                  <option>11</option>
                  <option>12</option>
                  <option>13</option>
                  <option>14</option>
                  <option>15</option>
                  <option>16</option>
                  <option>17</option>
                  <option>18</option>
                  <option>19</option>
                  <option>20</option>
                  <option>21</option>
                  <option>22</option>
                  <option>23</option>
                </select>
              </div>
              <div class="form-group col-4">
                <label for="minuto">
                  Minutos
                </label>
                <select class="form-control" id="minuto" name="minutos">
                  <option>00</option>
                  <option>15</option>
                  <option>30</option>
                  <option>45</option>
                </select>
              </div>
            </div>
          </div>

        
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">        
            Guardar anuncio
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Detalles de anuncio -->
<div class="modal fade bd-example-modal-lg" id="detalleAnuncio" tabindex="-1" role="dialog" aria-labelledby="detalleAnuncioLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="detalleAnuncioLabel">
          Detalles del anuncio
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form>
        <div class="modal-body">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Puntos</th>
                <th>URL</th>
                <th>Estado</th>
                <th>Ciudad</th>
              </tr>
            </thead>
            <tbody id="mostrar_detalles_anuncios">
              
            </tbody>
          </table>
        
        </div>
        <div class="modal-footer">
         

        </div>
      </form>
    </div>
  </div>
</div>

<!-- Editar anuncio -->
<div class="modal fade" id="editarAnuncio" tabindex="-1" role="dialog" aria-labelledby="editarAnuncioLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editarAnuncioLabel">
          ¡Editar anuncio!
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form>
        <div class="modal-body">
          

        
        </div>
        <div class="modal-footer">
          
          <button type="submit" class="btn btn-primary">        
            Editar anuncio
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Eliminar anuncio -->
<div class="modal fade" id="Eliminar" tabindex="-1" role="dialog" aria-labelledby="EliminarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EliminarLabel">
          Eliminar anuncio
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form_delete_anuncio">
        <div class="modal-body">
          ¿Estás seguro que quieres eliminar el anuncio <strong>"nombre de anuncio"</strong>?
        
        </div>
        <input type="hidden" name="id">
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">        
            Eliminar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php footerAdmin($data) ?>
