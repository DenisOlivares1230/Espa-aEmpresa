let url = 'http://localhost/Plataforma_referidos/';


export {url};
