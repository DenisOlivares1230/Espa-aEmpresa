let d = document,
	$mostrar_anuncios = d.getElementById('mostrar_anuncios'),
	$mostrar_detalles_anuncios = d.getElementById('mostrar_detalles_anuncios'),
	$form_city = d.getElementById('form_city'),
	$id_mandar = d.getElementById('id_mandar');

import {url} from './global.js';
let assets = `${url}Assets/`

const mostrar_anuncios = async ()=>{

	let options= {
		method: 'POST',
		body: null
	};

	let res = await fetch(`${url}BateriaAnuncios/mostrarAnuncios`,options),
		json = await res.json();


	for(let i = 0; i < json.length; i++){

		
		let mostrar = `<tr class='anuncio'>
	                    <th class="id">${json[i]['id']}</th>
	                    <th><img src="${assets}images/Uploads/anuncios/${json[i]['imagen']}" style="width: 60px"></th>
	                    <th>${json[i]['nombre']}</th>
	                    <th>10 puntos</th>
	                    <th>
	                      <button type="button" class="btn btn-primary btnDetalles" data-toggle="modal" data-target="#detalleAnuncio" data-id='${json[i]['id']}'>
	                        Detalles
	                      </button>
	                    </th>
	                  </tr>`;

		$mostrar_anuncios.insertAdjacentHTML('beforeend', mostrar);

	}

	let btnDetalles = d.querySelectorAll('.btnDetalles');

	for(let i = 0; i < $mostrar_anuncios.children.length; i++){
		btnDetalles[i].addEventListener('click', ()=>{
			mostrar_detalles_anuncios(btnDetalles[i].dataset.id);

		})

	}
}
const mostrar_detalles_anuncios =  async ($id)=>{

	let options = {
		method: 'POST',
		body: null
	};

	$form_city.innerHTML = "";
	let res = await fetch(`${url}BateriaAnuncios/mostrarAnuncio/${$id}`,options),
		json = await res.json();

		$id_mandar.id.value = json['id']; 
		let mostrar = `<tr>
		                <th>${json['id']}</th>
		                <th>${json['nombre']}</th>
		                <th>${json['puntos']}</th>
		                <th>${json['url']}</th>
		                <th>${json['numero']}</th>
		                <th>${ciudad(json['ciudad'])}</th>
		              </tr>`;

		$mostrar_detalles_anuncios.innerHTML = mostrar;
		//insert_form_ciudad();
		if (json['ciudad'] == 'sin adquirir') {
			
			let mostrar2 =	`<div class="input-group">
					            <select class="custom-select" id="select_ciudad" name="ciudad">
					            	<option selected>Asigna una ciudad</option>
					                <option>One</option>
					                <option>Two</option>
					                <option>Three</option>
					            </select>
					            <div class="input-group-append">
					            	<button class="btn btn-outline-secondary" type="submit">
					                  Establecer
					                </button>
					            </div>
				            </div>`;
	
		$form_city.innerHTML = mostrar2;
	}else{
		return "";
	}
}


const ciudad = (ciudad)=>{
	if (ciudad == 'sin adquirir') {
		return 'sin asignar';
	}else{
		return ciudad;
	}

}

$form_city.addEventListener('submit', async (e)=>{

	let formData = new FormData($form_city);

	e.preventDefault(e);
	let options = {
		method: 'POST',
		body: formData
	};

	let res = await fetch(`${url}BateriaAnuncios/actualizarCiudad}`,options),
		json = await res.json();

	console.log(json);

})
d.addEventListener('DOMContentLoaded', ()=>{
	mostrar_anuncios();
})
