let d = document,
	$mostrar_usuarios = d.getElementById('mostrar_usuarios'),
	$form_edit = d.getElementById('form_edit'),
	$form_delete = d.getElementById('form_delete'),
	$buscar_usuario = d.getElementById('buscar_usuario'),
	$inputs = d.querySelectorAll('.inputs');

import {url} from './global.js';
let assets = `${url}Assets/`;
	
let campos ={
	nombre: false,
	correo: false
};

let expresiones = {
	nombre: /^[ a-zA-ZñÑáéíóúÁÉÍÓÚ]+$/,
	correo: /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/
} 


const mostrar_datos_form_edit =  async ()=>{

	let options = {
		method: 'GET',
		body: null
	};

	let res = await fetch(`${url}Usuarios/mostrarUsuario/${$form_edit.id.value}`, options),
		json = await res.json();

	//console.log(json);



	$form_edit.nombre.value = json['usuario'];
	$form_edit.correo.value = json['correo'];
	$form_edit.password.value = json['password'];
	let options_edit = $form_edit.select_edit.children;
	
	for(let i = 0;i< options_edit.length;i++){options_edit[i].removeAttribute('selected');}
	
	for(let i = 0; i< options_edit.length; i++){
		
		if (json['nivel'] == options_edit[i].value) {
			options_edit[i].setAttribute('selected','');

		}
		

	}
}
const mostrar_usuarios = async ()=>{

	let options = {
		method: 'POST', 
		body: null
	};

	let res = await fetch(`${url}Usuarios/mostrarUsuarios`, options),
		json = await res.json();

	
	$mostrar_usuarios.innerHTML = "";
	for(let i = 0; i < json.length; i++){

		let mostrar = `<tr class='usuario'>
		                  <th class="id">${json[i]['id']}</th>
		                  <th><img src="${assets}images/Uploads/usuarios/${json[i]['photo']}" style="width: 35px"></th>
		                  <th>${json[i]['usuario']}</th>
		                  <th>${json[i]['nivel']}</th>
		                  <th>${json[i]['correo']}</th>
		                  <th>
		                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#actividad" data-id='${json[i]['id']}'>
		                      Actividad
		                    </button>

		                    <button type="button" class="btn btn-primary btnEdit" data-toggle="modal" data-target="#Editar" data-id='${json[i]['id']}'>
		                      Editar
		                    </button>
		                    
		                    <button type="button" class="btn btn-danger btnDelete" data-toggle="modal" data-target="#Eliminar" data-id='${json[i]['id']}'>
		                      Eliminar
		                    </button>	                  
		                  </th>
		                </tr>`;


		$mostrar_usuarios.insertAdjacentHTML('afterbegin', mostrar);


	}

	let btnDelete = d.querySelectorAll('.btnDelete'),
		btnEdit = d.querySelectorAll('.btnEdit');

	for(let i = 0; i < $mostrar_usuarios.children.length; i++){
		btnEdit[i].addEventListener('click', ()=>{
			$form_edit.id.value = btnEdit[i].dataset.id;
			mostrar_datos_form_edit();
		})
		btnDelete[i].addEventListener('click', ()=>{
			$form_delete.id.value = btnDelete[i].dataset.id;
		})
	}
}	
const buscar = async ()=>{

		let options = {
				method: 'POST',
				body: null
		};

		let res = await fetch(`${url}Usuarios/buscarUsuario/${$buscar_usuario.usuario.value}`, options),
			json = await res.json();
		
		$mostrar_usuarios.innerHTML = "";
		for(let i = 0; i< json.length; i++){

			console.log(json[i]);
			let mostrar = `<tr class='usuario'>
		                  <th class="id">${json[i]['id']}</th>
		                  <th><img src="${assets}images/Uploads/usuarios/${json[i]['photo']}" style="width: 35px"></th>
		                  <th>${json[i]['usuario']}</th>
		                  <th>${json[i]['nivel']}</th>
		                  <th>${json[i]['correo']}</th>
		                  <th>
		                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#actividad" data-id='${json[i]['id']}'>
		                      Actividad
		                    </button>

		                    <button type="button" class="btn btn-primary btnEdit" data-toggle="modal" data-target="#Editar" data-id='${json[i]['id']}'>
		                      Editar
		                    </button>
		                    
		                    <button type="button" class="btn btn-danger btnDelete" data-toggle="modal" data-target="#Eliminar" data-id='${json[i]['id']}'>
		                      Eliminar
		                    </button>	                  
		                  </th>
		                </tr>`;

		    $mostrar_usuarios.insertAdjacentHTML('afterbegin', mostrar);

		}

		let btnDelete = d.querySelectorAll('.btnDelete'),
		btnEdit = d.querySelectorAll('.btnEdit');

		for(let i = 0; i < $mostrar_usuarios.children.length; i++){
			btnEdit[i].addEventListener('click', ()=>{
				$form_edit.id.value = btnEdit[i].dataset.id;
				mostrar_datos_form_edit();
			})
			btnDelete[i].addEventListener('click', ()=>{
				$form_delete.id.value = btnDelete[i].dataset.id;
			})
		}

}

const validacion = (e)=>{
	switch(e.target.name){
		case 'nombre':
			validarCampo(expresiones.nombre,'nombre',e);
			break;
		case 'correo':
			validarCampo(expresiones.correo,'correo',e);
			break;
	}
}

const validarCampo = (expresion,campo,e)=>{
	
	if (expresion.test(e.target.value)) {
		e.target.classList.add('is-valid');
		e.target.classList.remove('is-invalid');
		campos[campo] = true;
	}else{
		e.target.classList.remove('is-valid');
		e.target.classList.add('is-invalid');
		campos[campo] = false;
	}
}

$buscar_usuario.addEventListener('keyup', async (e)=>{
	e.preventDefault(e);
	buscar();

})	
$buscar_usuario.addEventListener('submit', async (e)=>{
	e.preventDefault(e);
	buscar();
})
for(let i = 0; i < $inputs.length; i++){
	$inputs[i].addEventListener('keyup',(e)=>{
		validacion(e);

	})
	$inputs[i].addEventListener('focus',(e)=>{
		validacion(e);

	})
}
$form_edit.addEventListener('submit', async (e)=>{
	e.preventDefault(e);

	let formData = new FormData($form_edit); 

	let options= {
		method: 'POST',
		body: formData}

	if (campos['nombre'] && campos['correo']) {

		let res = await fetch(`${url}Usuarios/actulizarUsuario`, options);
		mostrar_usuarios();
		
	}else{
		alert('Sus datos no se pudieron enviar correctamente');

	}
})
$form_delete.addEventListener('submit', async (e)=>{
	e.preventDefault(e);

	let options = {
		method: 'POST',
		body: null
	};

	let res = await fetch(`${url}Usuarios/borrarUsuario/${$form_delete.id.value}`,options);

	mostrar_usuarios();
})
d.addEventListener('DOMContentLoaded', (e)=>{
	mostrar_usuarios();

})

