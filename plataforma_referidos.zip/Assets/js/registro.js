let d = document,
	$form_registro = d.getElementById('form_registro'),
	$revisar_datos = d.getElementById('revisar_datos'),
	$inputs = d.querySelectorAll('.inputs');

const campos = {
	nombre: false,
	correo: false,
	password: false
}
const expresion ={
	nombre: /^[ a-zA-ZñÑáéíóúÁÉÍÓÚ]+$/,
	correo: /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/
}
const validacion = (e)=>{
	switch(e.target.name){
		case "nombre":
			validarCampo(expresion.nombre,"nombre",e);
			break;
		case "correo":
			validarCampo(expresion.correo,"correo",e);
			break;
		case "passV":
			validarPass("password",e);
			espacios_vacios("password");
			break;
		/*case "password":
			validarPassword();
			break;	*/	
	}
}
const validarPass = (campo, e)=>{
	
	let pass1 = $form_registro.pass;

	if (pass1.value == e.target.value) {
		e.target.classList.add('is-valid');
		e.target.classList.remove('is-invalid');
		pass1.classList.add('is-valid');
		pass1.classList.remove('is-invalid');
		campos[campo] = true;
	}else{
		e.target.classList.add('is-invalid');
		e.target.classList.remove('is-valid');
		pass1.classList.add('is-invalid');
		pass1.classList.remove('is-valid');
		campos[campo] = false;
	}
}
const validarCampo = (expresion,campo,e)=>{

	if (expresion.test(e.target.value)) {
		e.target.classList.add('is-valid');
		e.target.classList.remove('is-invalid');
		campos[campo] = true;

	}else{
		e.target.classList.add('is-invalid');
		e.target.classList.remove('is-valid');
		campos[campo] = false;

	}
}
const espacios_vacios = (campo)=>{
	if ($form_registro.passV.value.length == 0) {
		$form_registro.passV.classList.add('is-invalid');
		$form_registro.passV.classList.remove('is-valid');
		$form_registro.pass.classList.add('is-invalid');
		$form_registro.pass.classList.remove('is-valid');
		campos[campo] = false;
	}
}
const incorrecto = ()=>{
	$revisar_datos.classList.add('alert');
	$revisar_datos.classList.add('alert-danger');
	$revisar_datos.classList.add('p-2');
	$revisar_datos.classList.add('text-center');
	$revisar_datos.innerHTML = '¡Revisa tus datos correctamente!';
}


for (let i = 0; i < $inputs.length; i++) {
	$inputs[i].addEventListener('keyup',(e)=>{
		validacion(e);
	})	
}
$form_registro.addEventListener('submit',(e)=>{

	if(campos['nombre'] && campos['correo'] && campos['password']){
		
			
			
			
		

	}else{
		e.preventDefault(e);
		incorrecto();
	}

})



