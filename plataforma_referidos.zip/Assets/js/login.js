let d = document,
	$form_login = d.getElementById('form_login'),
	$revisar_datos = d.getElementById('revisar_datos'),
	$inputs = d.querySelectorAll('.inputs');

const campos = {
	correo: false
}
const expresion ={
	correo: /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/
	
}
const validacion = (e)=>{
	switch(e.target.name){
		case 'correo':
			validarCampo(expresion.correo, 'correo', e);
			break;

	}

}
const validarCampo = (expresion, campo, e)=>{
	if (expresion.test(e.target.value)) {
		e.target.classList.add('is-valid');
		e.target.classList.remove('is-invalid');
		campos[campo] = true;
	}else{
		e.target.classList.add('is-invalid');
		e.target.classList.remove('is-valid');
		campos[campo] = false;
	}
}
const incorrecto = ()=>{
	$revisar_datos.classList.add('alert');
	$revisar_datos.classList.add('alert-danger');
	$revisar_datos.classList.add('p-2');
	$revisar_datos.classList.add('text-center');
	$revisar_datos.innerHTML = '¡Revisa tus datos correctamente!';
}


for (let i = 0; i < $inputs.length; i++){
	$inputs[i].addEventListener('keyup',(e)=>{
		validacion(e);
	})
}
$form_login.addEventListener('submit',  (e)=>{

	if (campos['correo']) {


	}else{
		e.preventDefault(e);
		incorrecto();
	}

})

