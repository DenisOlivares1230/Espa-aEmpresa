let d = document,
	$mostrar_anuncios = d.getElementById('mostrar_anuncios'),
	$form_adquirir = d.getElementById('form_adquirir');

import {url} from './global.js';
let assets = `${url}Assets/`;

const mostrar_anuncios = async()=>{

	let options = {
		method: 'POST',
		body: null
	}
	$mostrar_anuncios.innerHTML = '';
	let res = await fetch(`${url}CartelAnunciosUser/mostrarAnuncios`, options),
		json = await res.json();

	for (let i = 0; i < json.length; i++) {
		
		let mostrar = `<div class="col-md-4 col-6 mb-4">
			          <div class="card" style="width: 18rem;">
			            <img src="${assets}images/Uploads/anuncios/${json[i]['imagen']}" class="card-img-top" alt="..." style="height: 200px;">
			            <div class="card-body">
			                
			                <h5 class="card-title">${json[i]['nombre']}</h5>
			                <div class="alert alert-primary" role="alert">
			                  <strong>${json[i]['puntos']} puntos</strong>  
			                </div>
			              
			                <div class="alert alert-danger" >
			                  	<h5>  
				                  <strong>Expira en: ${expiracion(json[i]['expiracion'])}</strong>
		                		</h5>
			                </div>

			                <!-- Button trigger modal -->
			                <button type="button" class="btn btn-primary btnAdquirir" data-toggle="modal" data-target="#Adquirir" data-id='${json[i]['id']}'>
			                  ¡Adquirir!
			                </button>

			            </div>
			          </div>
			        </div>`;
		if (expiracion(json[i]['expiracion']) == "EXPIRADO") {
		}else{
			$mostrar_anuncios.insertAdjacentHTML('beforeend',mostrar);

		}
	}

	let btnAdquirir = d.querySelectorAll('.btnAdquirir');

	for(let i = 0;i < $mostrar_anuncios.children.length; i++){
		btnAdquirir[i].addEventListener('click', ()=>{
			$form_adquirir.id.value = btnAdquirir[i].dataset.id;
		})

	}
}
const expiracion = (fecha)=>{

	/*Fecha y hora actual*/
	let fechaActual = new Date(),
		fechaExpiracion = new Date(fecha);
		
	let diferenciaDia = (fechaExpiracion.getTime()-fechaActual.getTime())/1000/(3600*24),
		diferenciaHora = (fechaExpiracion.getTime()-fechaActual.getTime())/1000/(3600);
	
	if (Math.abs(diferenciaDia) < 1) {

		return `${Math.abs(Math.round(diferenciaHora))} horas`;

	}else{

		if (Math.sign(diferenciaDia) == -1) {
			return  "EXPIRADO";
		}else{
			return `${Math.abs(Math.round(diferenciaDia))} días`;
		}

	}
}

$form_adquirir.addEventListener('submit', async (e)=>{
	e.preventDefault(e);

	let options = {
		method: 'POST',
		body: null
	};

	let res = await fetch(`${url}CartelAnunciosUser/adquirirAnuncio/${$form_adquirir.id.value}`,options);

	mostrar_anuncios();



})
d.addEventListener('DOMContentLoaded', ()=>{

	mostrar_anuncios();

})


