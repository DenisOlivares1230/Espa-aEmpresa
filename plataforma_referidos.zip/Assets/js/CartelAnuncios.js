let d = document,
	$mostrar_cartel_anuncios = d.getElementById('mostrar_cartel_anuncios'),
	$form_delete = d.getElementById('form_delete'),
	$form_renovar = d.getElementById('form_renovar');

import {url} from './global.js';
let assets = `${url}Assets/`;

const mostrar_cartel_anuncios = async ()=>{

	let options = {
		method: 'POST',
		body: null
	};

	let res = await fetch(`${url}CartelAnuncios/MostrarAnunciosCartel`, options),
		json = await res.json();

	
	$mostrar_cartel_anuncios.innerHTML = "";
	for (let i = 0; i < json.length; i++) {
		
		//console.log(json[i]['expiracion']);

		let mostrar = `<div class="col-md-4 col-6 mb-4 anuncio">
					          <div class="card" style="width: 18rem;">
					            <img src="${assets}/images/uploads/anuncios/${json[i]['imagen']}" class="card-img-top" alt="...">
					            <div class="card-body">
					                
					                <h5 class="card-title">${json[i]['nombre']}</h5>

					                <div class="alert alert-primary" role="alert">
					                	<h5
						                  <strong>Puntos: ${json[i]['puntos']}</strong>  
					                	</h5>
					                </div>
					              
					                <div class="alert alert-danger" >
					                	<h5>  
						                  <strong>Expira en: ${expiracion(json[i]['expiracion'])}</strong>
					                	</h5>
					                </div>

					                <!-- Button trigger modal -->
					                <button type="button" class="btn btn-primary btnRenovar" data-toggle="modal" data-target="#configuracion" data-id='${json[i]['id']}'>
					                  Renovar
					                </button>

					                <button type="button" class="btn btn-danger btnDelete" data-toggle="modal" data-target="#Eliminar" data-id='${json[i]['id']}'>
					                  Eliminar
					                </button>

					            </div>
					          </div>
					        </div>`;

		$mostrar_cartel_anuncios.insertAdjacentHTML('beforeend',mostrar);


	}

	let btnDelete = d.querySelectorAll('.btnDelete'),
		btnRenovar = d.querySelectorAll('.btnRenovar');

	for(let i = 0; i < $mostrar_cartel_anuncios.children.length; i++){
		btnDelete[i].addEventListener('click', ()=>{
			$form_delete.id.value = btnDelete[i].dataset.id;
		})
		btnRenovar[i].addEventListener('click', ()=>{
			$form_renovar.id.value = btnRenovar[i].dataset.id;
		})


	}
}

const expiracion = (fecha)=>{

	/*Fecha y hora actual*/
	let fechaActual = new Date(),
		fechaExpiracion = new Date(fecha);
		
	let diferenciaDia = (fechaExpiracion.getTime()-fechaActual.getTime())/1000/(3600*24),
		diferenciaHora = (fechaExpiracion.getTime()-fechaActual.getTime())/1000/(3600);
	
	if (Math.abs(diferenciaDia) < 1) {

		return `${Math.abs(Math.round(diferenciaHora))} horas`;

	}else{

		if (Math.sign(diferenciaDia) == -1) {
			return  "EXPIRADO";
		}else{
			return `${Math.abs(Math.round(diferenciaDia))} días`;
		}

	}
}


$form_renovar.addEventListener('submit', async (e)=>{
	e.preventDefault(e);

	let formData = new FormData($form_renovar),
		options = {
			method: 'POST',
			body: formData
		};

	let res= await fetch (`${url}CartelAnuncios/CambiarFechaExpiracion`, options);

	mostrar_cartel_anuncios();

})
$form_delete.addEventListener('submit', async (e)=>{
	e.preventDefault(e);

	let options = {
		method: 'POST',
		body: null
	};

	let res = await fetch(`${url}CartelAnuncios/BorrarAnunciosCartel/${$form_delete.id.value}`, options);

	mostrar_cartel_anuncios();

})


d.addEventListener('DOMContentLoaded', ()=>{


	mostrar_cartel_anuncios();
	

})



