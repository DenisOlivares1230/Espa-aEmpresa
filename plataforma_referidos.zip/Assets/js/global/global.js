export const funcion = ()=>{
	alert("nsrnfv");

}