let d = document,
	$form_add_anuncio = d.getElementById('form_add_anuncio'),
	$inputs = d.querySelectorAll('.inputs'),
	$mostrar_anuncios = d.getElementById('mostrar_anuncios'),
	$mostrar_detalles_anuncios = d.getElementById('mostrar_detalles_anuncios'),
	$form_delete_anuncio = d.getElementById('form_delete_anuncio');

import {url} from './global.js';
let assets = `${url}Assets/`;

const campos = {
	nombre: false,
	numeros: false,
	puntos: false,
	url: false
}
const expresion ={
	nombre: /^[ a-zA-ZñÑáéíóúÁÉÍÓÚ]+$/,
	numeros:/^[0-9]+$/,
	puntos:/^[0-9]{1,4}$/,
	url:/^(ht|f)tps?:\/\/\w+([\.\-\w]+)?\.[a-z]{2,10}(:\d{2,5})?(\/.*)?$/i
}


const detalles = async (detalId)=>{

	let options = {
		method: 'GET',
		body: null
	};
	let res = await fetch(`${url}Anuncios/mostrarAnuncio/${detalId}`, options),
		json = await res.json();

	if (parseInt(json['adquirido'])) {

		let options = {
			method: 'GET',
			body: null
		};
		let res = await fetch(`${url}Anuncios/mostrarAnunciobyUser/${json['user_id']}`, options),
			json = await res.json();

	}else{
		insertar = 'Sin adquirir';
	}
	
	let mostrar =	`<tr class='detalles'>
				        <th>${json['id']}</th>
				        <th>${json['nombre']}</th>
				        <th>${json['puntos']}</th>
				        <th>${json['url']}</th>
				        <th>${insertar}</th>
				        <th>${json['ciudad']}</th>
				      </tr>`;

	$mostrar_detalles_anuncios.innerHTML = mostrar;


}

/*MOSTRAR ANUNCIOS*/
const mostrar_anuncios = async ()=>{


	let options = {
		method: 'POST',
		body: null
	};
	let res = await fetch(`${url}Anuncios/mostrarAnuncios`, options),
		json = await res.json();

	$mostrar_anuncios.innerHTML = ``;
	for(let i = 0; i < json.length; i++){
	
		let mostrar = `<tr class='anuncio'>
	                    <th class="id">${json[i]['id']}</th>
	                    <th><img src="${assets}/images/Uploads/anuncios/${json[i]['imagen']}" style="width: 60px"></th>
	                    <th>${json[i]['nombre']}</th>
	                    <th>${json[i]['expiracion']}</th>
	                    <th>${json[i]['puntos']} puntos</th>
	                    <th>${parseInt(json[i]['adquirido'])?"Adquirido":'Sin adquirir'}</th>
	                    <th>
	                      <button type="button" class="btn btn-primary detalleAnuncio" data-toggle="modal" data-target="#detalleAnuncio" data-id='${json[i]['id']}'>
	                        Detalles
	                      </button>

	                      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editarAnuncio" data-id='${json[i]['id']}'>
	                        Editar
	                      </button>
	                      
	                      <button type="button" class="btn btn-danger eliminarAnuncio" data-toggle="modal" data-target="#Eliminar" data-id='${json[i]['id']}'>
	                        Eliminar
	                      </button>
	                    </th>
	                  </tr>`;

	    
        $mostrar_anuncios.insertAdjacentHTML('afterbegin',mostrar);
	}

	let detalleAnuncio = d.querySelectorAll('.detalleAnuncio'),
		eliminarAnuncio = d.querySelectorAll('.eliminarAnuncio');


	for(let i = 0; i < $mostrar_anuncios.children.length; i++){
		eliminarAnuncio[i].addEventListener('click',()=>{
			$form_delete_anuncio.id.value = eliminarAnuncio[i].dataset.id;
		})
		detalleAnuncio[i].addEventListener('click', ()=>{
			detalles(detalleAnuncio[i].dataset.id);

		})		

	}
}
/*MOSTRAR ANUNCIOS*/
const validacion = (e)=>{
	switch(e.target.name){
		case "nombre":
			validarCampo(expresion.nombre,"nombre",e);
			break;
		case "numeros":
			validarCampo(expresion.numeros,"numeros",e);
			break;
		case "puntos":
			validarCampo(expresion.puntos,"puntos",e);
			break;
		case "url":
			validarCampo(expresion.url,"url",e);
			break;
		
	}
}
const validarCampo = (expresion,campo,e)=>{

	if (expresion.test(e.target.value)) {
		e.target.classList.add('is-valid');
		e.target.classList.remove('is-invalid');
		campos[campo] = true;

	}else{
		e.target.classList.add('is-invalid');
		e.target.classList.remove('is-valid');
		campos[campo] = false;
	}
}
const insertar_anuncios = async ()=>{

	let formData = new FormData($form_add_anuncio);
		//texto = quill.container.firstChild.innerHTML;


		let options = {
			method: 'POST',
			body: formData
		};

		let res = await fetch(`${url}Anuncios/Insertar`, options);

		mostrar_anuncios();	
}
for(let i = 0; i < $inputs.length; i++){
	$inputs[i].addEventListener('keyup', (e)=>{
		validacion(e);
	})
}

$form_delete_anuncio.addEventListener('submit', async(e)=>{
	e.preventDefault(e);
	let id = $form_delete_anuncio.id.value;

	let options = {
			method: 'POST',
			body: null
		};

	let res = await fetch(`${url}Anuncios/borrarAnuncio/${id}`, options);
	mostrar_anuncios();	
});
$form_add_anuncio.addEventListener('submit', (e)=>{
	e.preventDefault(e);
	
	if(campos['nombre'] && campos['numeros'] && campos['puntos'] 
		&& campos['url']){
		insertar_anuncios();
	}
});

d.addEventListener('DOMContentLoaded',()=>{

	mostrar_anuncios();

})