<?php
class CartelAnuncios extends SessionController{
		
	private $CartelAnunciosModel; 

	public function __construct(){
		
		parent::__construct();

		$this->CartelAnunciosModel = new CartelAnunciosModel();

	}
	public function CartelAnuncios ($params){

		$data["tag_name"] = "Cartel anuncios";
		$data["page_title"] = "Página principal";
		
		$this->views->getView($this, "CartelAnuncios", $data);
	}
	public function MostrarAnunciosCartel (){
		echo json_encode($this->CartelAnunciosModel->getAll());   
	}
	public function CambiarFechaExpiracion(){

		$this->CartelAnunciosModel->setId($_POST['id']);
		$this->CartelAnunciosModel->setExpiracion(
											$_POST['agno'],
											$_POST['mes'],
											$_POST['dia'],
											$_POST['hora'],
											$_POST['minutos']);

		$this->CartelAnunciosModel->updateExpiracion();

	}
	public function BorrarAnunciosCartel($id){

		$this->CartelAnunciosModel->borrar($id);

	}
}
