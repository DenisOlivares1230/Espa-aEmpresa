<?php

class Registro extends Controllers{
	
	public $user;
	public $session;
	
	public $usuario;
	public $correo;
	public $pass;

	public function __construct(){
		
		parent::__construct();


	}
	public function Registro(){
		
		$data['tag_name'] = "Registro";
		$this->views->getView($this, "Registro", $data);
	}
	public function verificarCuenta(){
		if (!$this->existPost([ 'nombre',
								'correo',	
								'pass',
								'passV'])) {
					return;
			}
			
			$this->session = new Session();

			$token = token();
			$message = "
				<html>
				<head>
				<title>HTML</title>
				</head>
				<body>
				<h1>Verifica tu usuario</h1>
				<p>Estás a un paso de registrarte en nuestro sístema</p>
				<p>Usa el siguiente código: ".$token."</p>
				</body>
				</html>";

			
			$from = "plataformaAfiliados@gmail.com";
			$para = $_POST['correo'];
			$headers = "From: ".$from."\r\n"; 
			$headers .= "Reply-To: $from\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=utf-8\r\n";

			$_SESSION['token'] = $token;
			$_SESSION['usuario'] = $_POST['nombre'];
			$_SESSION['correo'] = $_POST['correo'];
			$_SESSION['pass'] = $_POST['pass'];
			mail($para,"Verificar cuenta",$message,$headers);
			
			$data['tag_name'] = 'Verificar cuenta';
			$this->views->getView($this, "verificarCuenta", $data);	
	}
	function ValidarVerificarUsuario(){
			
			$this->session = new Session();

			$this->user = new RegistroModel();

			if (!$this->existPost(['token'])) {
				echo "Problema 1";
				return;}
			if ($this->user == NULL) {
				echo "Problema 2";
				return;}
			
			if ($_SESSION['token'] == $_POST['token']) {
				
				/*echo "Su cuenta fue creada con éxito";*/

				$this->user->nuevoUsuario(
					$_SESSION['usuario'],
					$_SESSION['correo'],
					$_SESSION['pass']);
				$this->session->closeSession();

				header("Location: ".base_url()."/Login");
			}	
	}
	
	
}
