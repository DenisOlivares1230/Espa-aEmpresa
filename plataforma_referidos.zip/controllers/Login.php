<?php

class Login extends SessionController{
	
	public function __construct(){
		
		parent::__construct();


	}
	public function Login(){
		$data['tag_name'] = 'Login';

		$this->views->getView($this, "Login",$data);
	}
	function Authenticate(){
			
			if($this->existPost(['correo', 'password'])){
				
				$correo = $this->getPost('correo');
				$password = $this->getPost('password');
				//validacion de datos
					
				if($correo == '' || empty($correo) || $password == '' || empty($password)){

					header("Location: ".base_url().'/Login');
					return;
				}
					//Modelo login
					$user = $this->model->selectUser($correo, $password);
					if ($user != NULL) {
						
						$this->initialize($user);

						/*echo $username."<br>";
						echo($password."<br>");
						
						dep($user);*/

					}else{

						header("Location: ".base_url()."/Login");

						return;

					}
						


			}
	}
	
}
