<?php
class Usuarios extends SessionController{
	
	public function __construct(){
		
		parent::__construct();

		$this->UsuarioModel = new UsuarioModel();

	}
	public function Usuarios ($params){

		$data["tag_name"] = "Usuarios";
		$data["page_title"] = "Página principal";
		$data["page_name"] = "";

		

		$this->views->getView($this, "Usuarios", $data);
	}
	public function mostrarUsuarios(){
		 echo json_encode($this->UsuarioModel->getAll());
	}
	public function mostrarUsuario ($id){
		echo json_encode($this->UsuarioModel->getUser($id));
	}
	public function actulizarUsuario(){
		$this->UsuarioModel->setUsuario($_POST['nombre']);
		$this->UsuarioModel->setCorreo($_POST['correo']);
		$this->UsuarioModel->setPassword2($_POST['password']);
		$this->UsuarioModel->setNivel($_POST['select_edit']);
		$this->UsuarioModel->setId($_POST['id']);
		dep($_POST);
		$this->UsuarioModel->updateUser();
	}
	public function borrarUsuario ($id){
		$this->UsuarioModel->borrar($id);

	}
	public function buscarUsuario ($text){
		echo json_encode($this->UsuarioModel->searchUser($text));

	}
	
}