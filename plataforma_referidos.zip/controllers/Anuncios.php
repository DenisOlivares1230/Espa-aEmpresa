<?php
class Anuncios extends SessionController{
	
	private $anuncio;
	public function __construct(){
		
		parent::__construct();

		$this->anuncio = new AnunciosModel();

	}
	public function Anuncios ($params){

		$data["tag_name"] = "Anuncios";
		$data["page_title"] = "Página principal";
		$data["page_name"] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,";

		

		$this->views->getView($this, "Anuncios", $data);
	}
	public function Insertar (){


		if (!$this->existPost([
			'nombre','numeros','puntos','url','agno','mes','dia','hora','minutos'])){
			return;
		}
		
		
		$this->anuncio->setNombre($_POST['nombre']);
		$this->anuncio->setImagen($_FILES['imagen']);
		$this->anuncio->setNumero($_POST['numeros']);
		$this->anuncio->setPuntos($_POST['puntos']);
		$this->anuncio->setUrl($_POST['url']);
		$this->anuncio->setExpiracion($_POST['agno'],$_POST['mes'],
							$_POST['dia'],$_POST['hora'],$_POST['minutos']);
		
		$this->anuncio->save();

		echo "hecho con éxito";
	}
	public function mostrarAnuncios (){
		echo json_encode($this->anuncio->getAll());
	}
	public function mostrarAnuncio ($id){
		echo json_encode($this->anuncio->get($id));
	}
	public function borrarAnuncio ($id){
		$this->anuncio->borrar($id);
		echo "Archivo borrado";
	}	
}