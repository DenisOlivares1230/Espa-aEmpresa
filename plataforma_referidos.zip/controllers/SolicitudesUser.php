<?php
class SolicitudesUser extends SessionController{
	
	public function __construct(){
		
		parent::__construct();

	}
	public function SolicitudesUser ($params){

		$data["tag_name"] = "Solicitudes";
		$data["page_title"] = "Página principal";
		
		$this->views->getView($this, "SolicitudesUser", $data);
	}
	
}